import * as AvatarPrimitive from "@radix-ui/react-avatar"
import { cn } from "../../lib/utils"

export function Avatar({ className, ...props }) {
  return <AvatarPrimitive.Root className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)} {...props} />
}

export function AvatarFallback({ className, ...props }) {
  return <AvatarPrimitive.Fallback className={cn("flex h-full w-full items-center justify-center rounded-full bg-[#F7F4EC] text-sm font-black text-[#1B4D2E]", className)} {...props} />
}
