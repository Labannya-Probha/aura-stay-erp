export { default } from "./GlobalSearch"
